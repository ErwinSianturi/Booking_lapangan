@extends('layout.admin')
 
@section('title', 'Laravel 10 Login SignUp with User Roles and Permissions with Admin CRUD | Tailwind CSS Custom Login register')
 
@section('contents')
<div>
    <h1 class="font-bold text-2xl ml-3">Dashboard</h1>
</div>
@endsection