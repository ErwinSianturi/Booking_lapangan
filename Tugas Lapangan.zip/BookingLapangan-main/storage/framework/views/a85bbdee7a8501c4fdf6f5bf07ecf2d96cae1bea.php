<?php $__env->startSection('title', 'Home Product List'); ?>

<?php $__env->startSection('contents'); ?>
    <div class="container">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <div class="row justify-content-center">
            <div class="container">
                <h1>Produk</h1>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Nama Produk</th>
                            <th>Harga</th>
                            <th>Stok</th>
                            <th>Gambar</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data_produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->nama_produkolahraga); ?></td>
                                <td><?php echo e($item->harga_produkolahraga); ?></td>
                                <td><?php echo e($item->stok_produkolahraga); ?></td>
                                <td>
                                    <?php if($item->img_product): ?>
                                        <img src="<?php echo e(asset('storage/' . $item->img_product)); ?>" alt="<?php echo e($item->nama_produkolahraga); ?>" style="max-width: 100px;">
                                    <?php else: ?>
                                        No Image
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a href="<?php echo e(route('update_product', $item->id_produkolahraga)); ?>"
                                            class="btn btn-success m-2">Edit</a>
                                        <a href="<?php echo e(route('detail_product', $item->id_produkolahraga)); ?>"
                                            class="btn btn-success m-2">Detail</a>
                                        <form action="<?php echo e(route('product_destroy', $item->id_produkolahraga)); ?>"
                                            method="POST"
                                            onsubmit="return confirm('Apakah anda yakin ingin menghapus?')"
                                            class="float-right text-red-800">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-danger m-2">Delete</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>
                <button type="button" class="btn btn-primary m-2"
                            onclick="window.location='<?php echo e(route('form_create')); ?>'">+ Add</button>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Instalasi Laravel\BookingLapangan-main\resources\views/product/product.blade.php ENDPATH**/ ?>