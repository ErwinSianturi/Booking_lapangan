<?php $__env->startSection('title', 'My Bookings >'); ?>
<?php $__env->startSection('sub_title', 'Booking Detail >'); ?>
<?php $__env->startSection('dynamic_nav_links'); ?>

    <li class="nav-item">
        <a class="nav-link" href="#"><?php echo e($booking->lapangan->nama_lapangan); ?></a>
    </li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8 offset-md-2">
                <h2>Booking Detail</h2>
                <div class="mb-3">
                    <label for="nama">Nama Pemesan:</label>
                    <input type="text" id="nama" class="form-control" value="<?php echo e($booking->nama_pemesan); ?>" readonly>
                </div>
                <div class="mb-3">
                    <label for="email">Email Pemesan:</label>
                    <input type="email" id="email" class="form-control" value="<?php echo e($booking->email_pemesan); ?>"
                        readonly>
                </div>
                <div class="mb-3">
                    <label for="lapangan">Lapangan:</label>
                    <input type="text" id="lapangan" class="form-control"
                        value="<?php echo e($booking->lapangan->nama_lapangan); ?>" readonly>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="waktu_mulai">Waktu Mulai:</label>
                        <input type="text" id="waktu_mulai" class="form-control"
                            value="<?php echo e($booking->waktu_mulai_booking); ?>" readonly>
                    </div>
                    <div class="col-md-6">
                        <label for="waktu_selesai">Waktu Selesai:</label>
                        <input type="text" id="waktu_selesai" class="form-control"
                            value="<?php echo e($booking->waktu_selesai_booking); ?>" readonly>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="catatan">Catatan:</label>
                    <textarea id="catatan" class="form-control" readonly><?php echo e($booking->catatan); ?></textarea>
                </div>
                <div class="mb-3">
                    <label for="status">Status:</label>
                    <input type="text" id="status" class="form-control" value="<?php echo e($booking->status); ?>" readonly>
                </div>
            </div>
        </div>
        <button type="button" class="btn btn-secondary"
            onclick="window.location='<?php echo e(route('booking_info')); ?>'">Back</button>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Instalasi Laravel\BookingLapangan-main\resources\views/booking/detail_user.blade.php ENDPATH**/ ?>