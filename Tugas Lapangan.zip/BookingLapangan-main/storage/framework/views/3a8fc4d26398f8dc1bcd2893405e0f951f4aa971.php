<?php $__env->startSection('title', 'Keranjang Belanja'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <div class="row">
            <div class="col-md-8">
                <table class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Nama Produk</th>
                            <th>Harga</th>
                            <th>Jumlah</th>
                            <th>Total</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Isi tabel keranjang belanja dengan data dari transaksi olahraga -->
                        <?php $__currentLoopData = $transaksi_olahraga; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $transaksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td><?php echo e($transaksi->product->nama_produkolahraga); ?></td>
                                <td>Rp <?php echo e(number_format($transaksi->product->harga_produkolahraga, 0, ',', '.')); ?></td>
                                <td><?php echo e($transaksi->jumlah); ?></td>
                                <!-- Hitung total harga untuk setiap transaksi -->
                                <?php
                                    $total = $transaksi->jumlah * $transaksi->product->harga_produkolahraga;
                                ?>
                                <td>Rp <?php echo e(number_format($total, 0, ',', '.')); ?></td>
                                <td>
                                    <!-- Tambahkan tombol untuk menghapus produk dari keranjang belanja -->
                                    <!-- Tambahkan tombol untuk menghapus produk dari keranjang belanja -->
                                    <form action="<?php echo e(route('keranjang.hapus', $transaksi->id_transaksi_olahraga)); ?>"
                                        method="POST"
                                        onsubmit="return confirm('Apakah Anda yakin ingin menghapus produk dari keranjang belanja?');">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger">Batal</button>
                                    </form>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="col-md-4">
                <!-- Isi bagian kanan dengan ringkasan total pembelian dan tombol checkout -->
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Ringkasan Belanja</h5>
                        <!-- Hitung total produk -->
                        <?php
                            $total_produk = 0;
                            foreach ($transaksi_olahraga as $transaksi) {
                                $total_produk += $transaksi->jumlah;
                            }
                        ?>
                        <p class="card-text">Total Produk: <?php echo e($total_produk); ?></p>
                        
                        <?php
                            $total_harga = 0;
                            foreach ($transaksi_olahraga as $transaksi) {
                                $total_harga += $transaksi->jumlah * $transaksi->product->harga_produkolahraga;
                            }
                        ?>
                        <p class="card-text">Total Harga: Rp <?php echo e(number_format($total_harga, 0, ',', '.')); ?></p>
                        <a href="<?php echo e(route('checkout')); ?>" class="btn btn-primary">Checkout</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Instalasi Laravel\BookingLapangan-main\resources\views/product/user_keranjang.blade.php ENDPATH**/ ?>