<?php $__env->startSection('title', 'Jadwal Lapangan yang telah Anda Pesan'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">

                <?php if($jadwal->isEmpty()): ?>
                    <h2>Tidak ada jadwal lapangan yang sedang berlangsung saat ini.</h2>
                <?php else: ?>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Nama Lapangan</th>
                                <th>Nama Pemesan</th>
                                <th>Waktu Mulai Booking</th>
                                <th>Waktu Selesai Booking</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $jadwal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($index + 1); ?></td>
                                    <td><?php echo e($booking->lapangan->nama_lapangan); ?></td>
                                    <td><?php echo e($booking->nama_pemesan); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($booking->waktu_mulai_booking)->format('d/m/Y H:i')); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($booking->waktu_selesai_booking)->format('d/m/Y H:i')); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Instalasi Laravel\BookingLapangan-main\resources\views/booking/jadwal.blade.php ENDPATH**/ ?>