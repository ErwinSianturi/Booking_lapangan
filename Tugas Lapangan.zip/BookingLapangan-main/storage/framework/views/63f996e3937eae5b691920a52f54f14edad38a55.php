<?php $__env->startSection('title', 'Pengelola Details'); ?>

<?php $__env->startSection('contents'); ?>
    <div class="container">
        <h1>Player List</h1>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Last Login</th>
                    <th>Jenis Pelanggan</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($player->id_pengguna); ?></td>
                        <td><?php echo e($player->username_pengguna); ?></td>
                        <td><?php echo e($player->last_login); ?></td>
                        <td><?php echo e(optional($player->pelanggan)->jenis_pelanggan ?? 'Biasa'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Instalasi Laravel\BookingLapangan-main\resources\views/player/player.blade.php ENDPATH**/ ?>