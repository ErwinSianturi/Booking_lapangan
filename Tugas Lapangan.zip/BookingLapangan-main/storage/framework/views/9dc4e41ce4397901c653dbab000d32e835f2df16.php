<?php $__env->startSection('title', 'My Bookings'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-12">
                <h2>My Bookings</h2>
                <table class="table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Lapangan</th>
                            <th>Waktu Mulai</th>
                            <th>Waktu Selesai</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($booking->lapangan->nama_lapangan); ?></td>
                                <td><?php echo e($booking->waktu_mulai_booking); ?></td>
                                <td><?php echo e($booking->waktu_selesai_booking); ?></td>
                                <td>
                                    <?php if($booking->status == 'approve'): ?>
                                        Approve
                                    <?php elseif($booking->status == 'not approve'): ?>
                                        Not Approve
                                    <?php else: ?>
                                        Still Waiting
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($booking->status == ''): ?>
                                        <a href="<?php echo e(route('booking.edit', $booking->id_booking_olahraga)); ?>"
                                            class="btn btn-primary">Edit</a>
                                        
                                        <a href=""
                                            class="btn btn-danger">Batal</a>
                                    <?php endif; ?>
                                    <a href="<?php echo e(route('booking.detail', $booking->id_booking_olahraga)); ?>"
                                        class="btn btn-info">Detail</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6">No bookings found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>

                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Instalasi Laravel\UAS-PRAK-11423051\resources\views/booking/info_booking.blade.php ENDPATH**/ ?>